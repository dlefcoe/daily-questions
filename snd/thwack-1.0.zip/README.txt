Name:
  Thwack Sounds
Version:
  1.0
Description:
  Just some simple 'thwack' sounds made by hitting things.
Licensing:
  - Creative Commons Zero (CC0) (see: LICENSE.txt)
Attribution (not required):
  Created by Jordan Irwin (AntumDeluge)
